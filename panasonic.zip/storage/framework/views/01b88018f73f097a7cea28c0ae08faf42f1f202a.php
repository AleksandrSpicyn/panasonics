<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?>">
    <title>Panasonic</title>
    <link href="/css/app.css" rel="stylesheet">
    <script src="/js/app.js"></script>
    <script>
        mindbox = window.mindbox || function () {
            mindbox.queue.push(arguments);
        };
        mindbox.queue = mindbox.queue || [];
        mindbox('create');
    </script>
    <script src="https://api.mindbox.ru/scripts/v1/tracker.js" async></script>
</head>
<body>

<?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH C:\Users\feny8\PhpstormProjects\panasonic\cirquedusoleil\resources\views/app.blade.php ENDPATH**/ ?>