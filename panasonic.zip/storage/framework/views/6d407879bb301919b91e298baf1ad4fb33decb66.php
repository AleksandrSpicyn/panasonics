<ul class="list-group">
    <li class="list-group-item">
        <a href="/admin"><?php echo e(__('app.all')); ?></a>
    </li>
    <li class="list-group-item">
        <a href="/admin/<?php echo e(App\Job::JOB_ACCEPT_STATUS); ?>"><?php echo e(__('app.'.App\Job::JOB_ACCEPT_STATUS)); ?></a>
    </li>
    <li class="list-group-item">
        <a href="/admin/<?php echo e(App\Job::JOB_WAIT_STATUS); ?>"><?php echo e(__('app.'.App\Job::JOB_WAIT_STATUS)); ?></a>
    </li>
    <li class="list-group-item">
        <a href="/admin/<?php echo e(App\Job::JOB_REFUSE_STATUS); ?>"><?php echo e(__('app.'.App\Job::JOB_REFUSE_STATUS)); ?></a>
    </li>
    <li class="list-group-item">
        <a href="/admin/<?php echo e(App\Job::JOB_DELETE_STATUS); ?>"><?php echo e(__('app.'.App\Job::JOB_DELETE_STATUS)); ?></a>
    </li>
</ul><?php /**PATH C:\Users\feny8\PhpstormProjects\panasonic\resources\views/menu.blade.php ENDPATH**/ ?>