<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('header'); ?>
    <?php echo $__env->renderComponent(); ?>
    <section id="content">
        <div class="container">
            <div class="row">
                <div class="col-4">
                    <?php $__env->startComponent('menu'); ?>
                    <?php echo $__env->renderComponent(); ?>
                </div>
                <div class="col-8">
                    <form action="" class="admin-job">
                        <input id="id" class="" type="hidden" name="id" value="<?php echo e($job["id"]); ?>">
                        <div class="form-group">
                            <label for="title"><?php echo e(__('app.title')); ?></label>
                            <input id="title" class="form-control" type="text" name="title" value="<?php echo e($job["title"]); ?>">
                        </div>
                        <div class="form-group">
                            <label for="created_at"><?php echo e(__('app.created_at')); ?></label>
                            <div class="input-group date" id="datetimepicker1" data-target-input="nearest">
                                <input id="created_at" type="text" class="form-control datetimepicker-input"
                                       data-target="#datetimepicker1" name="created_at"
                                       value="<?php echo e(date('Y-m-d H:i',strtotime($job["created_at"]))); ?>"/>
                                <div class="input-group-append" data-target="#datetimepicker1"
                                     data-toggle="datetimepicker">
                                    <div class="input-group-text"><i class="fa fa-calendar"></i></div>
                                </div>
                            </div>
                        </div>
                        <div class="form-group">
                            <label for="likes"><?php echo e(__('app.likes')); ?></label>
                            <input id="likes" class="form-control" type="text" name="" disabled value="<?php echo e($likes); ?>">
                        </div>
                        <div class="form-group">
                            <label for="email"><?php echo e(__('app.email')); ?></label>
                            <input id="email" class="form-control" type="text" name="" disabled
                                   value="<?php echo e($job["user"]['email']); ?>">
                        </div>
                        <div class="form-group">
                            <label for="fio"><?php echo e(__('app.fio')); ?></label>
                            <input id="fio" class="form-control" type="text" name="" disabled
                                   value="<?php echo e($job["user"]['first_name'].' '.$job["user"]['second_name']); ?>">
                        </div>
                        
                        
                        
                        
                        
                        
                        
                        
                        <div class="form-group">
                            <label for="description"><?php echo e(__('app.description')); ?></label>
                            <textarea class="form-control" name="description" id="description" cols="30"
                                      rows="3"><?php echo e($job["description"]); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="status"><?php echo e(__('app.status')); ?></label>
                            <select id="status" class="form-control" name="status">
                                <option <?php if(App\Job::JOB_ACCEPT_STATUS == $job["status"]): ?> selected
                                        <?php endif; ?> value="<?php echo e(App\Job::JOB_ACCEPT_STATUS); ?>"><?php echo e(__('app.'.App\Job::JOB_ACCEPT_STATUS)); ?></option>
                                <option <?php if(App\Job::JOB_WAIT_STATUS == $job["status"]): ?> selected
                                        <?php endif; ?> value="<?php echo e(App\Job::JOB_WAIT_STATUS); ?>"><?php echo e(__('app.'.App\Job::JOB_WAIT_STATUS)); ?></option>
                                <option <?php if(App\Job::JOB_REFUSE_STATUS == $job["status"]): ?> selected
                                        <?php endif; ?> value="<?php echo e(App\Job::JOB_REFUSE_STATUS); ?>"><?php echo e(__('app.'.App\Job::JOB_REFUSE_STATUS)); ?></option>
                                <option <?php if(App\Job::JOB_DELETE_STATUS == $job["status"]): ?> selected
                                        <?php endif; ?> value="<?php echo e(App\Job::JOB_DELETE_STATUS); ?>"><?php echo e(__('app.'.App\Job::JOB_DELETE_STATUS)); ?></option>
                            </select>
                        </div>
                        <div class="form-group">
                            <label for="comment"><?php echo e(__('app.refused_comment')); ?></label>
                            <textarea class="form-control" name="comment" id="comment" cols="30"
                                      rows="3"><?php echo e($job["comment"]); ?></textarea>
                        </div>
                        <div class="form-group">
                            <label for="uploadimage"><?php echo e(__('app.download_image')); ?></label>
                            <input type="file" id="uploadimage" name="image">
                            <img class="img-fluid job-admin-image" src="<?php echo e(Storage::url($job["image"])); ?>" alt="">
                            <div>
                                <p>
                                    <a target="_blank" class="d-inline-block mr-2  mt-2 btn btn-info"
                                       href="https://yandex.ru/images/search?url=<?php echo e(Storage::url($job["image"])); ?>&rpt=imageview"><?php echo e(__('app.image_unique')); ?>

                                    </a>
                                </p>
                                <a href="#" class="image-rotate d-inline-block mr-2  mb-2 btn btn-info"
                                   data-degree="-90" data-job="<?php echo e($job["id"]); ?>">
                                    Повернуть по часовой
                                </a>
                                <a href="#" class="image-rotate d-inline-block mr-2  mb-2 btn btn-info" data-degree="90"
                                   data-job="<?php echo e($job["id"]); ?>">
                                    Повернуть против часовой
                                </a>
                                <p>Внимание! После поворота ориентация картинки сохранится без нажатия на кнопку
                                    сохранения</p>
                            </div>


                        </div>
                        <div class="form-group">
                            <button class="btn btn-primary submit-admin-job"><?php echo e(__('app.save')); ?></button>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\feny8\PhpstormProjects\panasonic\resources\views/job.blade.php ENDPATH**/ ?>