<section id="header">
    <div class="container">
        <div class="row align-items-center">
            <div class="col text-left">
                <div class="logo">
                    <a href="/">
                        <img src="/assets/img/Panasonic_logo.png" alt="">
                    </a>
                </div>
            </div>
            <div class="col text-right">
                <div class="event-logo">
                    <img src="/assets/img/user1.png" class="d-inline-block pr-1" alt="">
                    <?php if(Auth::check()): ?>
                        <a href="#" class="d-inline-block text-uppercase font-weight-200 black text-decoration-none"
                           data-toggle="modal"
                           data-target="#ProfileModal"><?php echo e(__('app.profile_in')); ?></a>
                        <span class="pl-2 pr-2 text-center font-weight-200 ">|</span>
                        <a href="#" id="logout" class="d-inline-block text-uppercase font-weight-200 black text-decoration-none"><?php echo e(__('app.logout')); ?></a>
                    <?php else: ?>
                        <a href="#" class="d-inline-block text-uppercase font-weight-200 black text-decoration-none" data-toggle="modal"
                           data-target="#AuthModal"><?php echo e(__('app.entry')); ?></a>
                        <span class="pl-2 pr-2 text-center font-weight-200 ">|</span>
                        <a href="#" class="d-inline-block text-uppercase font-weight-200 black text-decoration-none" data-toggle="modal"
                           data-target="#RegisterModal"><?php echo e(__('app.in_register')); ?></a>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</section><?php /**PATH C:\Users\feny8\PhpstormProjects\panasonic\cirquedusoleil\resources\views/header.blade.php ENDPATH**/ ?>