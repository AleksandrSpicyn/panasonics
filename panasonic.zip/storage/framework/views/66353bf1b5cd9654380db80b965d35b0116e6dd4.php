<?php $__env->startSection('content'); ?>
    <?php $__env->startComponent('header'); ?>
    <?php echo $__env->renderComponent(); ?>
    <section id="content">
        <div class="container">
            <div class="row">
                <div class="col-4">
                    <?php $__env->startComponent('menu'); ?>
                    <?php echo $__env->renderComponent(); ?>
                </div>
                <div class="col-8">
                    <table class="table table-bordered table-hover">
                        <thead>
                        <tr>
                            <td>ID</td>
                            <td><?php echo e(__('app.title')); ?></td>
                            <td><?php echo e(__('app.created_at')); ?></td>
                            <td><?php echo e(__('app.status')); ?></td>
                        </tr>
                        </thead>
                        <tbody>
                        <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <tr data-href="/job/<?php echo e($job["id"]); ?>">
                                <td><?php echo e($job["id"]); ?></td>
                                <td><?php echo e($job["title"]); ?></td>
                                <td><?php echo e($job["created_at"]); ?></td>
                                <td><?php echo e(__('app.'.$job["status"])); ?></td>
                            </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </tbody>
                    </table>
                    <?php echo $jobs->render(); ?>
                </div>
            </div>
        </div>

    </section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\feny8\PhpstormProjects\panasonic\resources\views/jobs.blade.php ENDPATH**/ ?>