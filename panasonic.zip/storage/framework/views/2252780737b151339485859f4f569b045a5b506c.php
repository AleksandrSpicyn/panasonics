<?php if($userJob): ?>
    <?php $__env->startComponent('job_front', ['job' => $userJob, 'likes' => $likes, 'me' => true]); ?>
    <?php echo $__env->renderComponent(); ?>
<?php endif; ?>
<?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <?php $__env->startComponent('job_front', ['job' => $job, 'likes' => $likes, 'me' => false]); ?>
    <?php echo $__env->renderComponent(); ?>
<?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?><?php /**PATH C:\Users\feny8\PhpstormProjects\panasonic\resources\views/jobs_list.blade.php ENDPATH**/ ?>