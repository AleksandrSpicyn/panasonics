<div class="modal fade front-modal" id="ThanksModal" tabindex="-1" role="dialog" aria-labelledby="ThanksModal"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <a class="close-modal" data-dismiss="modal" aria-label="Close">
                    <img src="/assets/img/cross.png" alt="">
                </a>
            </div>
            <div class="modal-body text-center">
                <h2 class="main-color font-weight-500"><?php echo e(__('app.thanks')); ?></h2>
                <p class="font-weight-300 mt-3"><?php echo e(__('app.your_job_moderate')); ?></p>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\feny8\PhpstormProjects\panasonic\resources\views/thanks.blade.php ENDPATH**/ ?>