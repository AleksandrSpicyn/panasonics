<div class="col-12 col-lg-6 mb-2 pr-1 pl-1">
    <div class="card <?php if($me): ?> me-card <?php endif; ?> ">
        <div class="row no-gutters">
            <div class="col-12 col-sm-6 text-center">
                <img src="<?php echo e(Storage::url($job["image"])); ?>" class="img-fluid" alt="">
                <a class="k-lightbox" data-title="<?php echo e($job["title"]); ?>"
                   data-footer="<?php echo e($job["user"]["first_name"]); ?> <?php echo e($job["user"]["second_name"]); ?>"
                   data-toggle="lightbox"
                   href="<?php echo e(Storage::url($job["image"])); ?>">
                    <span class="fa-stack fa-lg">
                    <i class="fa fa-circle fa-stack-2x"></i>
                    <i class="fa fa-search fa-stack-1x fa-inverse"></i>
                    </span>
                    <img src="<?php echo e(Storage::url($job["image"])); ?>" class="img-fluid d-none" alt="">
                </a>
            </div>
            <div class="col-12 col-sm-6">
                <div class="card-block job-block">
                    <h4 class="text-center text-sm-left card-title job-title font-weight-500">
                        <?php echo e($job["title"]); ?>

                        <?php if($me): ?>
                            <a href="#" class="d-inline-block text-uppercase font-weight-200 black text-decoration-none"
                               data-toggle="modal"
                               data-target="#JobModal"
                               titke="Редактировать"
                            >
                                <i class="fa fa-edit"></i>
                            </a>
                        <?php endif; ?>
                    </h4>
                    <p class="text-center text-sm-left job-likes "><span
                                class="like-count font-weight-bold"><?php echo e(count($job["likes"])); ?></span>
                        <?php if(Auth::check()): ?>
                            <i
                                    class="like-job fa fa-thumbs-o-up font-weight-400 <?php if(in_array($job["id"], $likes)): ?> active <?php endif; ?>"
                                    aria-hidden="true" job="<?php echo e($job["id"]); ?>"></i>
                        <?php else: ?>
                            <i
                                    data-toggle="modal"
                                    data-target="#VoteModal"
                                    class="fa fa-thumbs-o-up font-weight-400 <?php if(in_array($job["id"], $likes)): ?> active <?php endif; ?>"
                                    aria-hidden="true" job="<?php echo e($job["id"]); ?>"></i>
                        <?php endif; ?>
                    </p>
                    <div class="text-center text-sm-left author-meta">
                        <img src="/assets/img/user2.png" class="job-author" alt="">
                        <span class="author-name"><?php echo e($job["user"]["first_name"]); ?> <?php echo e($job["user"]["second_name"]); ?></span>
                    </div>
                    <?php if($job["status"] == App\Job::JOB_ACCEPT_STATUS): ?>
                        <div class="job-share">
                            <p class="text-center text-sm-left font-weight-500 black job-share-title"><?php echo e(__('app.share')); ?>

                                :</p>
                            <ul class="text-center text-sm-left ">
                                <li>
                                <span data-job="<?php echo e($job["id"]); ?>"
                                      data-url="https://vk.com/share.php?title=<?php echo e($job["title"]); ?>&url=<?php echo e(ENV('APP_URL')); ?>&image=<?php echo e(ENV('SITE_URL').Storage::url($job["image"])); ?>"
                                      data-provider="vk" class="share-button fa-stack fa-lg">
                                <i class="fa fa-vk fa-stack-1x"></i>
                                </span>
                                </li>
                                <li>
                                <span
                                        data-job="<?php echo e($job["id"]); ?>"
                                        data-url="https://connect.ok.ru/offer?url=<?php echo e(ENV('APP_URL')); ?>&imageUrl=<?php echo e(ENV('SITE_URL').Storage::url($job["image"])); ?>"
                                        data-provider="ok" class="share-button fa-stack fa-lg">
                                <i class="fa fa-odnoklassniki fa-stack-1x"></i>
                                </span>
                                </li>
                                <li>
                                <span data-job="<?php echo e($job["id"]); ?>"
                                      data-url="https://www.facebook.com/sharer.php?u=<?php echo e(ENV('APP_URL')); ?>"
                                      data-provider="fb" class="share-button fa-stack fa-lg">
                                <i class="fa fa-facebook fa-stack-1x"></i>
                                </span>
                                </li>
                            </ul>
                        </div>
                    <?php endif; ?>
                    <?php if($me): ?>
                        <div>
                            <p class="text-center text-sm-left font-weight-500 black job-share-title"><?php echo e(__('app.status')); ?>

                                :</p>
                            <p><?php echo e(__('app.'.$job["status"])); ?></p>
                        </div>
                    <?php endif; ?>
                </div>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\feny8\PhpstormProjects\panasonic\resources\views/job_front.blade.php ENDPATH**/ ?>