<div class="modal fade front-modal" id="ResetModal" tabindex="-1" role="dialog" aria-labelledby="ResetModal"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md" role="document">
        <div class="modal-content" id="reset">
            <div class="modal-header">
                <a class="close-modal" data-dismiss="modal" aria-label="Close">
                    <img src="/assets/img/cross.png" alt="">
                </a>
                <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('app.reseting_password')); ?></h5>
            </div>
            <div class="modal-body ">
                <form action="/reset" class="reset">
                    <div class="form-group">
                        <label for="email"><?php echo e(__('app.your_email')); ?></label>
                        <input id="email" class="form-control" type="text" name="email"
                               value="" placeholder="">
                    </div>
                    <a class="modal-submit modal-auth font-weight-300 text-center text-uppercase d-block"><?php echo e(__('app.reset_password')); ?></a>
                </form>
            </div>
        </div>
    </div>
</div>
<?php /**PATH C:\Users\feny8\PhpstormProjects\panasonic\cirquedusoleil\resources\views/reset.blade.php ENDPATH**/ ?>