<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <meta name="csrf-token" content="<?php echo e(csrf_token()); ?> ">
    <meta property="og:title" content="<?php echo e(__('app.power_up')); ?> - <?php echo e(__('app.show_talants')); ?>!"/>
    <meta property="og:description" content="<?php echo e(__('app.show_text')); ?>"/>
    <meta property="og:url" content="<?php echo e(ENV('APP_URL')); ?>"/>
    <meta property="og:image" content="https://cds.ru/img/social/crystal.png">
    <link rel="shortcut icon" href="/favicon1.ico">
    <title>Panasonic</title>
    <link href="<?php echo e(ENV('SUBFOLDER')); ?>/css/app.css" rel="stylesheet">
    <script src="<?php echo e(ENV('SUBFOLDER')); ?>/js/app.js"></script>
    <script>
        mindbox = window.mindbox || function () {
            mindbox.queue.push(arguments);
        };
        mindbox.queue = mindbox.queue || [];
        mindbox('create');
    </script>
    <script src="https://api.mindbox.ru/scripts/v1/tracker.js" async></script>
</head>
<body>
<?php echo $__env->yieldContent('content'); ?>
</body>
</html><?php /**PATH C:\Users\feny8\PhpstormProjects\panasonic\resources\views/app.blade.php ENDPATH**/ ?>