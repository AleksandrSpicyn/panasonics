<div class="modal front-modal fade" id="JobModal" tabindex="-1" role="dialog" aria-labelledby="JobModal"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <a class="close-modal" data-dismiss="modal" aria-label="Close">
                    <img src="/assets/img/cross.png" alt="">
                </a>
                <h5 class="modal-title" id="exampleModalLabel"><?php echo e(__('app.run_job')); ?></h5>
            </div>
            <div class="modal-body">
                <form action="" class="job">
                    <div class="form-group">
                        <label for="title"><?php echo e(__('app.title')); ?></label>
                        <input id="title" class="form-control" type="text" name="title"
                               value="<?php echo e($job["title"] ?? ''); ?>">
                        <div class="invalid-feedback">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="description"><?php echo e(__('app.description')); ?></label>
                        <textarea class="form-control" name="description" id="description" cols="30"
                                  rows="3"><?php echo e($job["description"] ?? ''); ?></textarea>
                        <div class="invalid-feedback">
                        </div>
                    </div>
                    <div class="form-group">
                        <label for="uploadimage">
                            <?php echo e(__('app.download_image')); ?>:
                        </label>
                        <img id="clip" src="/assets/img/clip.png" alt="">
                        <input class="form-control" type="file" id="uploadimage" name="img">
                        <div class="invalid-feedback">
                        </div>
                    </div>
                    <div class="custom-control custom-checkbox">
                        <input type="checkbox" class="custom-control-input form-control" id="privacy" name="privacy">
                        <label class="custom-control-label" for="privacy">
                            <?php echo e(__('app.accept_user_after')); ?>

                            <a class="open-hide-modal" data-open="#PrivacyModal" data-hide="#JobModal" href="" target="_blank"><?php echo e(__('app.accept_user_privacy')); ?></a>
                            <?php echo e(__('app.accept_user_before')); ?>

                        </label>
                        <div class="invalid-feedback">
                        </div>
                    </div>
                </form>
            </div>
            <div class="modal-footer">
                <a class="modal-submit submit-job font-weight-300 text-center text-uppercase"><?php echo e(__('app.download_job')); ?></a>
            </div>
        </div>
    </div>
</div><?php /**PATH C:\Users\feny8\PhpstormProjects\panasonic\resources\views/job_modal.blade.php ENDPATH**/ ?>