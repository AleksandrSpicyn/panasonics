<?php $__env->startSection('content'); ?>
    <div id="app">
        <?php $__env->startComponent('header'); ?>
        <?php echo $__env->renderComponent(); ?>
        <section id="top">
            <div class="container">
                <div class="row">
                    <div class="col text-right p-0 m-0">
                        <img class="d-logo" src="/assets/img/d-logo-ru.png" alt="">
                    </div>
                </div>
                <div class="row">
                    <div class="col-12 col-sm-12 col-xs-12 col-md-7 col-lg-7 col-xl-7">
                        <h1 id="event-title" class="text-uppercase main-color font-weight-bold"><?php echo e(__('app.job')); ?></h1>
                        <div class="desc">
                            <p class="text-uppercase font-weight-200 mb-0">Сила внутри - </p>
                            <p class="text-uppercase font-weight-400">Покажи таланты</p>
                        </div>
                        <div id="event-date">
                            <p class="font-weight-100">
                                2 сентябрь - 29 декабрь
                            </p>
                        </div>
                    </div>
                </div>
                <div id="top-second" class="row">
                    <div class="col-12 col-sm-6 col-md-6 col-lg-6 col-xl-6">
                        <h3 class="text-uppercase font-weight-400">
                            Сила внутри – Покажи таланты

                        </h3>
                        <p class="sub-desc font-weight-bold">
                            вместе с лимитированной серией батареек Panasonic, вдохновленной партнерством с<span
                                    class="font-italic">Cirque du Soleil®</span>

                        </p>
                        <p class="more-desc font-weight-200">
                            Каждое шоу Цирк дю Солей – это комбинация вдохновляющей музыки, потрясающих декораций,
                            продуманного сценария и, конечно же, высочайшего мастерства мирового уровня актеров шоу! Как
                            батарейки Panasonic благодаря своей энергоотдаче позволяют вдохнуть жизнь в устройства или
                            игрушки, так артисты Цирк дю Солей за счет твоего таланта и мастерства, дарят энергию
                            зрителям во всем мире. Сила внутри каждого из вас, вдохновитесь нашим партнерством с Цирк дю
                            Солей и лимитированной серией батареек Panasonic и покажите
                            свои таланты!
                        </p>

                    </div>
                    <div class="col-12 col-sm-6 col-md-6 col-lg-6 col-xl-6">
                        
                        <div id="countdown"></div>
                    </div>
                </div>
            </div>
        </section>
        <section id="top-third">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <p class="full text-lowercase font-weight-500">
                    <span>
                        <img src="/assets/img/download.png" alt="">
                    </span>
                            
                            <?php echo e(__('app.all_rules')); ?>

                        </p>
                    </div>
                </div>
            </div>
        </section>
        <section id="event">
            <div class="container">
                <div class="row">
                    <div class="col">
                        <h2 class="text-center text-uppercase main-color font-weight-400">
                            <?php echo e(__('app.run_job_qa')); ?>

                        </h2>
                    </div>
                </div>
                <div class="row energy-blocks">
                    <div class="col-12 col-sm-12 col-md-4 col-lg-4 col-xl-4 energy text-center">
                        <img src="/assets/img/four_energy.png" alt="">
                        <p class="text-center font-weight-300">Купи любые батарейки Panasonic
                            <span class="font-italic">Cirque du Soleil®</span></p>
                    </div>
                    <div class="col-12 col-sm-12 col-md-7 col-lg-7 col-xl-7 offset-0 offset-sm-0 offset-md-1 offset-lg-1 offset-xl-1  text-center pl-5">
                        <img id="girl" src="/assets/img/photo.jpg" alt="">
                        <p class="text-center font-weight-300">
                            Запечатли свой талант вместе с батарейками Panasonic
                            <span class="font-italic">Cirque du Soleil®</span> и выложи фото для участия в конкурсе
                        </p>
                    </div>
                </div>
                <div class="row">
                    <div class="col text-center">
                        <?php if(!Auth::check()): ?>
                            <a href="#" class="orange-event text-uppercase main-color-bg font-weight-500"
                               data-toggle="modal"
                               data-target="#AuthModal"><?php echo e(__('app.run_job')); ?></a>
                        <?php else: ?>
                            <?php if(!$user->jobs): ?>
                                <a href="#" class="orange-event text-uppercase main-color-bg font-weight-500"
                                   data-toggle="modal"
                                   data-target="#JobModal"><?php echo e(__('app.run_job')); ?></a>
                            <?php else: ?>
                                <a class="orange-event text-uppercase main-color-bg font-weight-500" data-toggle="modal"
                                   data-target="#JobModal"
                                ><?php echo e(__('app.allready_have_job')); ?></a>
                            <?php endif; ?>
                        <?php endif; ?>
                    </div>
                </div>
            </div>
        </section>
        <section id="prize">
            <div class="container">
                <div class="row">
                    <h2 class="text-center text-uppercase font-weight-400 main-color">ВЫИГРАЙ БИЛЕТЫ НА
                        НЕЗАБЫВАЕМОЕ ШОУ <span class="font-weight-bold font-italic text-normal">Cirque du Soleil®</span>
                        в москве!</h2>
                </div>
                <div class="row other-row  align-items-center">
                    <div class="col">
                        <p class="text-left text-uppercase font-weight-400 other">И ДРУГИЕ ПРИЗЫ PANASONIC
                        </p>
                    </div>
                    <div class="col text-right">
                        <img src="/assets/img/energy.png" alt="">
                    </div>
                </div>
                <div class="row">
                    <div class="col text-center magic">
                        <img src="/assets/img/bringmagicalive.png" alt="">
                    </div>
                </div>
                <div id="prize_two">
                    <div class="row">
                        <div class="col">
                            <h3 class="text-center text-uppercase font-weight-300">ОТКРОЙТЕ ДЛЯ СЕБЯ ЛИМИТИРОВАННУЮ
                                СЕРИЮ
                                БАТАРЕЕК PANASONIC,
                                <br>
                                вдохновленную партнерством с <span
                                        class="font-weight-bold font-italic text-normal">Cirque du Soleil®</span>
                            </h3>
                        </div>
                    </div>
                    <div class="row">
                        <div class="col text-center ">
                            <img src="/assets/img/lines.png" alt="">
                            <p class="text-center font-weight-300 white copyright"><span
                                        class="font-italic">Cirque du Soleil</span> и
                                логотип в виде солнца являются зарегистрированными торговыми марками и используются по
                                лицензии.<br>
                                Фото шоу “Crystal”: Мэтт Борода © 2019 Cirque du Soleil. Фото шоу “Luzia”: Мэтт Борода ©
                                2016 <span class="font-italic">Cirque du Soleil.</span></p>
                        </div>
                    </div>
                </div>
            </div>
        </section>
        <?php if($jobs->count() || $userJob): ?>
            <section id="jobs">
                <div class="container">
                    <div class="row">
                        <div class="col">
                            <h2 class="text-center text-uppercase main-color font-weight-400">
                                <?php echo e(__('app.jobs')); ?>

                            </h2>
                        </div>
                    </div>
                    <div class="row bg-grey">
                        <?php if($userJob): ?>
                            <?php $__env->startComponent('job_front', ['job' => $userJob, 'likes' => $likes]); ?>
                            <?php echo $__env->renderComponent(); ?>
                        <?php endif; ?>
                        <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <?php $__env->startComponent('job_front', ['job' => $job, 'likes' => $likes]); ?>
                            <?php echo $__env->renderComponent(); ?>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </div>
                    <div class="row">
                        <div class="col">
                            <p class="text-center">
                                <a href="/jobs" class="orange-event text-uppercase main-color-bg font-weight-500">Смотреть
                                    все
                                    работы</a>
                            </p>
                        </div>
                    </div>
                </div>
            </section>
        <?php endif; ?>
    </div>
    <!-- Modal -->
    <?php if(!Auth::check()): ?>
        <?php $__env->startComponent('auth'); ?>
        <?php echo $__env->renderComponent(); ?>
        <?php $__env->startComponent('register'); ?>
        <?php echo $__env->renderComponent(); ?>
        <?php $__env->startComponent('reset'); ?>
        <?php echo $__env->renderComponent(); ?>
    <?php else: ?>
        <?php $__env->startComponent('profile', ['user' => $user]); ?>
        <?php echo $__env->renderComponent(); ?>
        <?php if(!$userJob): ?>
            <?php $__env->startComponent('job_modal', ['job' => []]); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php else: ?>
            <?php $__env->startComponent('job_modal_edit', ['job'=>$userJob]); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php endif; ?>
    <?php endif; ?>
    <!-- END Modal -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\feny8\PhpstormProjects\panasonic\cirquedusoleil\resources\views/welcome.blade.php ENDPATH**/ ?>