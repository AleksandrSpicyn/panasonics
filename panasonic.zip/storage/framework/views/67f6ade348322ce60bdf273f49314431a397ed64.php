<?php $__env->startSection('content'); ?>
    <div id="app">
        <?php $__env->startComponent('header'); ?>
        <?php echo $__env->renderComponent(); ?>
        <section id="jobs" class="all-jobs">
            <div class="container">
                <div class="row align-items-center">
                    <div class="col-4">
                        <h2 class="text-uppercase main-color font-weight-400">
                            <?php echo e(__('app.all_jobs')); ?>

                        </h2>
                    </div>
                    <div class="col-8 text-right">
                        <a href="#" data-sort="date"
                           class="mt-2 mb-2 sort-trigger sort text-center text-uppercase font-weight-500 d-inline-block">
                            <?php echo e(__('app.sort_date')); ?>

                        </a>
                        <a href="#" data-sort="likes"
                           class="mt-2 mb-2 sort-trigger sort text-center text-uppercase font-weight-500 d-inline-block">
                            <?php echo e(__('app.sort_like')); ?>

                        </a>
                        <a href="/" data-sort=""
                           class="mt-2 mb-2 sort sort-orange text-center text-uppercase font-weight-500 d-inline-block">
                            <?php echo e(__('app.back')); ?>

                        </a>
                    </div>
                </div>
                <div class="row all-jobs-row">
                    <?php $__env->startComponent('jobs_list', ['jobs' => $jobs, 'likes' => $likes, 'userJob' => $userJob]); ?>
                    <?php echo $__env->renderComponent(); ?>
                </div>
                <div class="row">
                    <div class="col-12 text-center">
                        <a href="/"
                           data-page="1"
                           class="mt-5 mb-2 load-more sort sort-orange text-center text-uppercase font-weight-500 d-inline-block">
                            <?php echo e(__('app.load_more')); ?>

                        </a>
                    </div>
                </div>
            </div>
        </section>
    </div>
    <!-- Modal -->
    <?php if(!Auth::check()): ?>
        <?php $__env->startComponent('auth'); ?>
        <?php echo $__env->renderComponent(); ?>
        <?php $__env->startComponent('register'); ?>
        <?php echo $__env->renderComponent(); ?>
        <?php $__env->startComponent('reset'); ?>
        <?php echo $__env->renderComponent(); ?>
        <?php $__env->startComponent('success_reset'); ?>
        <?php echo $__env->renderComponent(); ?>
        <?php $__env->startComponent('only_register_vote'); ?>
        <?php echo $__env->renderComponent(); ?>
    <?php else: ?>
        <?php $__env->startComponent('profile', ['user' => $user]); ?>
        <?php echo $__env->renderComponent(); ?>
        <?php $__env->startComponent('switch_password'); ?>
        <?php echo $__env->renderComponent(); ?>
        <?php if(!$userJob): ?>
            <?php $__env->startComponent('job_modal', ['job' => []]); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php else: ?>
            <?php $__env->startComponent('job_modal_edit', ['job'=>$userJob]); ?>
            <?php echo $__env->renderComponent(); ?>
        <?php endif; ?>
    <?php endif; ?>
    <!-- END Modal -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make('app', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\feny8\PhpstormProjects\panasonic\resources\views/all_jobs.blade.php ENDPATH**/ ?>