<div class="modal fade front-modal" id="SuccessResetModal" tabindex="-1" role="dialog" aria-labelledby="SuccessResetModal"
     aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-md" role="document">
        <div class="modal-content" id="reset">
            <div class="modal-header">
                <a class="close-modal" data-dismiss="modal" aria-label="Close">
                    <img src="/assets/img/cross.png" alt="">
                </a>
            </div>
            <div class="modal-body text-center">
                <img src="/assets/img/check.png" alt="">
                <p class="font-weight-300">{{__('app.reset_link_success')}}</p>
            </div>
        </div>
    </div>
</div>
